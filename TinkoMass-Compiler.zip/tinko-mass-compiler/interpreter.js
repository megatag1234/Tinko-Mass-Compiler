// Tinko Mass Interpreter
function interpretTinkoMass(code) {
  const lines = code.split("\n");
  const output = [];
  const graphics = { enabled: false, width: 800, height: 600, elements: [] };
  let currentFill = "black";
  
  lines.forEach(line => {
    const t = line.trim();
    if (!t || t.startsWith("#")) return;
    
    if (t.match(/^\w+\s*=\s*"(.+)"$/)) {
      const m = t.match(/^(\w+)\s*=\s*"(.+)"$/);
      output.push("[VAR] " + m[1] + ' = "' + m[2] + '"');
    } else if (t.match(/^\w+\s*=\s*\d+$/)) {
      const m = t.match(/^(\w+)\s*=\s*(\d+)$/);
      output.push("[VAR] " + m[1] + " = " + m[2]);
    } else if (t.startsWith("log(")) {
      const content = t.slice(4, -1);
      if (content.startsWith("G,")) {
        const parts = content.slice(2).split(",").map(p => p.trim().replace(/"/g, ""));
        output.push("[GRAPHICS LOG] " + parts[0]);
        graphics.elements.push({type: "text", text: parts[0], x: parseInt(parts[2])||0, y: parseInt(parts[3])||0, color: currentFill});
      } else {
        output.push("[LOG] " + content.replace(/"/g, ""));
      }
    } else if (t.startsWith("graphics(")) {
      const params = t.slice(9, -1);
      const dims = params.split(",");
      graphics.enabled = true;
      graphics.width = parseInt(dims[0]) || 800;
      graphics.height = parseInt(dims[1]) || 600;
      output.push("[GRAPHICS] " + graphics.width + "x" + graphics.height);
    } else if (t === "load_info") {
      output.push("[REFRESH] Screen updated");
    } else if (t.startsWith("draw(")) {
      const params = t.slice(5, -1);
      const m = params.match(/rect:\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+)/);
      if (m) {
        output.push("[DRAW] Rectangle " + m[1] + "x" + m[2]);
        graphics.elements.push({type:"rect", width:parseInt(m[1]), height:parseInt(m[2]), x:parseInt(m[3]), y:parseInt(m[4]), fill:currentFill});
      }
    } else if (t.startsWith("fill(")) {
      const params = t.slice(5, -1);
      if (params.includes(",")) {
        const rgb = params.split(",").map(p => parseInt(p.trim()));
        currentFill = "rgb(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + ")";
      } else {
        currentFill = params.trim();
      }
      output.push("[FILL] " + currentFill);
    }
  });
  
  return { output: output.join("\n"), graphics };
}