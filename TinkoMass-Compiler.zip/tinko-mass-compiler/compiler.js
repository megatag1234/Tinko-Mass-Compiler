// Tinko Mass to Assembly/Binary Compiler
const OPCODES = {
  VAR_STR: "MOV", VAR_NUM: "LOAD", LOG: "PRINT", LOG_G: "DRAW_TEXT",
  GRAPHICS: "INIT_SCREEN", LOAD_INFO: "REFRESH", DRAW: "DRAW_RECT",
  FILL: "SET_COLOR", STROKE: "SET_STROKE", FONT: "SET_FONT",
  OS_SHUTDOWN: "SYS_HALT", OS_RESTART: "SYS_REBOOT", RET: "RET", NOP: "NOP"
};

function compileToAssembly(code) {
  const lines = code.split("\n");
  let asm = ["; Tinko Mass Assembly", "section .data", ""];
  let codeSection = ["section .text", "global _start", "_start:"];
  
  lines.forEach(line => {
    const t = line.trim();
    if (!t || t.startsWith("#")) return;
    
    if (t.match(/^\w+\s*=\s*"/)) codeSection.push("    MOV eax, " + t);
    else if (t.match(/^\w+\s*=\s*\d+/)) codeSection.push("    LOAD ebx, " + t);
    else if (t.startsWith("log(")) codeSection.push("    PRINT " + t.slice(4,-1));
    else if (t.startsWith("graphics(")) codeSection.push("    INIT_SCREEN " + t.slice(9,-1));
    else if (t === "load_info") codeSection.push("    REFRESH");
    else if (t.startsWith("draw(")) codeSection.push("    DRAW_RECT " + t.slice(5,-1));
    else if (t.startsWith("fill(")) codeSection.push("    SET_COLOR " + t.slice(5,-1));
    else codeSection.push("    NOP ; " + t);
  });
  
  codeSection.push("", "    RET");
  return [...asm, ...codeSection].join("\n");
}

function assemblyToBinary(asm) {
  const opcodes = {MOV:"10110000",LOAD:"10111000",PRINT:"11001101",INIT_SCREEN:"11010000",
    REFRESH:"11010001",DRAW_RECT:"11010010",SET_COLOR:"11010011",RET:"11000011",NOP:"10010000"};
  let binary = "";
  asm.split("\n").forEach(line => {
    const t = line.trim();
    for (const [op, bin] of Object.entries(opcodes)) {
      if (t.includes(op)) { binary += bin + " "; break; }
    }
  });
  return binary.trim();
}