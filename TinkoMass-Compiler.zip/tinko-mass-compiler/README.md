# 🧠⚙️ Tinko Mass Web Compiler

**Tinko Mass** is a custom programming language that can be:
- ✅ Interpreted live in the browser
- ✅ Compiled to Assembly
- ✅ Compiled all the way to Binary (`.bin`)

This project is a **full web-based IDE** for Tinko Mass — no installs, no servers, no nonsense.

---

## ✨ Features

- 📝 Code editor for `.mass`
- ▶️ **Test Run** (runs code instantly using the interpreter)
- 🧩 **Assembly output tab**
- 💾 **Binary output tab**
- 🎨 Built-in graphics system using a canvas
- 🌑 Clean dark UI, fully offline

---

## 🖥️ Interface Overview

The app is split into two sides:

### Left: Editor
- Write Tinko Mass code
- Buttons:
  - **Test Run** → runs code instantly
  - **Compile to .bin** → generates assembly + binary

### Right: Output
- **Test Output**  
  - Graphics canvas  
  - Runtime logs  
- **Assembly**  
  - Generated assembly code  
- **Binary**  
  - Final compiled binary output  

---

## 🚀 How to Use

1. Download or clone this repository
2. Open `index.html` in any modern browser (Chrome / Firefox)
3. Write or edit Tinko Mass code in the editor
4. Click:
   - **Test Run** to execute instantly
   - **Compile to .bin** to generate Assembly & Binary
5. Switch tabs to inspect the output

No internet required. Works 100% offline.

---

## 🧪 Example Code

```mass
graphics(800, 600)
fill(blue)
draw(rect: 200, 150, 100, 100)
fill(255, 0, 0)
draw(rect: 100, 100, 300, 200)
log(G, "Hello Tinko Mass!", 50, 100, 50)
load_info
