// Main application logic
let currentTab = 'test';

function showTab(tab) {
  currentTab = tab;
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById('testOutput').style.display = tab === 'test' ? 'block' : 'none';
  document.getElementById('assemblyOutput').style.display = tab === 'assembly' ? 'block' : 'none';
  document.getElementById('binaryOutput').style.display = tab === 'binary' ? 'block' : 'none';
}

function runCode() {
  const code = document.getElementById('codeEditor').value;
  const result = interpretTinkoMass(code);
  document.getElementById('testLog').textContent = result.output;
  
  if (result.graphics.enabled) {
    const canvas = document.getElementById('graphicsCanvas');
    canvas.width = result.graphics.width;
    canvas.height = result.graphics.height;
    canvas.style.display = 'block';
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    result.graphics.elements.forEach(el => {
      if (el.type === 'rect') {
        ctx.fillStyle = el.fill;
        ctx.fillRect(el.x, el.y, el.width, el.height);
      } else if (el.type === 'text') {
        ctx.fillStyle = el.color;
        ctx.font = '16px Arial';
        ctx.fillText(el.text, el.x, el.y);
      }
    });
  }
}

function compileCode() {
  const code = document.getElementById('codeEditor').value;
  const asm = compileToAssembly(code);
  const bin = assemblyToBinary(asm);
  document.getElementById('asmCode').textContent = asm;
  document.getElementById('binCode').textContent = bin;
}